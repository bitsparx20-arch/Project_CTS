import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import Logo from "./Logo";
import SocialIcons from "./SocialIcons";
import { COMPANY, CONTACT_ITEMS, FOOTER_LINKS } from "../config/site";

/* ─── constants ─────────────────────────────────────────────── */
const MONO   = "'Space Mono', monospace";
const RED    = "#C8121F";
const RED_HX = "#ff6b6b";

/* ═══════════════════════════════════════════════════════════════
   StarField — animated canvas particles
   ═══════════════════════════════════════════════════════════════ */
function StarField() {
  const ref = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d")!;
    let raf: number;

    const stars: { x: number; y: number; r: number; speed: number; o: number }[] = [];

    const resize = () => {
      canvas.width  = canvas.offsetWidth;
      canvas.height = canvas.offsetHeight;
    };
    resize();
    window.addEventListener("resize", resize);

    for (let i = 0; i < 280; i++)
      stars.push({ x: Math.random() * canvas.width, y: Math.random() * canvas.height, r: Math.random() * 1.2 + 0.2, speed: Math.random() * 0.16 + 0.04, o: Math.random() * 0.7 + 0.2 });

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      stars.forEach(s => {
        s.o  += (Math.random() - 0.5) * 0.014;
        s.o   = Math.max(0.08, Math.min(0.9, s.o));
        s.y  -= s.speed;
        if (s.y < -2) { s.y = canvas.height + 2; s.x = Math.random() * canvas.width; }
        ctx.beginPath();
        ctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,255,255,${s.o})`;
        ctx.fill();
      });
      raf = requestAnimationFrame(draw);
    };
    draw();

    return () => { cancelAnimationFrame(raf); window.removeEventListener("resize", resize); };
  }, []);

  return (
    <canvas
      ref={ref}
      style={{ position: "absolute", inset: 0, width: "100%", height: "100%", pointerEvents: "none" }}
    />
  );
}

/* ═══════════════════════════════════════════════════════════════
   TyreGlyph — wireframe tyre SVG (front-on view)
   ═══════════════════════════════════════════════════════════════ */
function TyreGlyph() {
  const CX = 200, CY = 200;
  const spokes = Array.from({ length: 7 }, (_, i) => {
    const rad = (i * (360 / 7) * Math.PI) / 180;
    return {
      x1: CX + 30 * Math.cos(rad), y1: CY + 30 * Math.sin(rad),
      x2: CX + 108 * Math.cos(rad), y2: CY + 108 * Math.sin(rad),
    };
  });
  const treads = Array.from({ length: 24 }, (_, i) => {
    const a1 = ((i * 15 - 90) * Math.PI) / 180;
    const a2 = (((i + 1) * 15 - 4 - 90) * Math.PI) / 180;
    const R = 186, r = 158;
    return [
      [CX + R * Math.cos(a1), CY + R * Math.sin(a1)],
      [CX + R * Math.cos(a2), CY + R * Math.sin(a2)],
      [CX + r * Math.cos(a2), CY + r * Math.sin(a2)],
      [CX + r * Math.cos(a1), CY + r * Math.sin(a1)],
    ];
  });

  return (
    <svg viewBox="0 0 400 400" fill="none" xmlns="http://www.w3.org/2000/svg"
      style={{ width: "100%", maxWidth: 440, display: "block", margin: "0 auto" }}>

      {/* Outer glow rings */}
      <ellipse cx={CX} cy={CY} rx={188} ry={188} stroke="rgba(200,18,31,.09)" strokeWidth="38" />
      <ellipse cx={CX} cy={CY} rx={188} ry={188} stroke="rgba(255,255,255,.07)" strokeWidth="1" />

      {/* Tread ring borders */}
      {[186, 165, 148, 132].map((r, i) => (
        <ellipse key={r} cx={CX} cy={CY} rx={r} ry={r}
          stroke={`rgba(255,255,255,${[.18,.14,.10,.07][i]})`}
          strokeWidth={i === 0 ? 1.5 : 1}
          strokeDasharray={i === 3 ? "5 7" : undefined}
        />
      ))}

      {/* Tread blocks */}
      {treads.map((pts, i) => (
        <polygon key={i}
          points={pts.map(p => p.join(",")).join(" ")}
          fill="rgba(200,18,31,.055)"
          stroke="rgba(255,255,255,.11)"
          strokeWidth=".7"
        />
      ))}

      {/* Rim */}
      <ellipse cx={CX} cy={CY} rx={110} ry={110} stroke="rgba(255,255,255,.20)" strokeWidth="1.5" />
      <ellipse cx={CX} cy={CY} rx={80}  ry={80}  stroke="rgba(255,255,255,.10)" strokeWidth="1" />

      {/* Spokes */}
      {spokes.map((s, i) => (
        <line key={i} x1={s.x1} y1={s.y1} x2={s.x2} y2={s.y2}
          stroke="rgba(255,255,255,.26)" strokeWidth="1.5" />
      ))}

      {/* Hub */}
      <ellipse cx={CX} cy={CY} rx={28} ry={28} stroke={RED} strokeWidth="2" fill="rgba(200,18,31,.1)" />
      <ellipse cx={CX} cy={CY} rx={11} ry={11} fill={RED} fillOpacity=".65" />

      {/* Red glow pool at bottom */}
      <ellipse cx={CX} cy={390} rx={140} ry={10} fill={RED} fillOpacity=".18" />
    </svg>
  );
}

/* ═══════════════════════════════════════════════════════════════
   Footer — main export
   ═══════════════════════════════════════════════════════════════ */
export default function Footer() {
  const footerRef = useRef<HTMLElement>(null);
  const [vis, setVis]       = useState(false);
  const [email, setEmail]   = useState("");
  const [subOk, setSubOk]   = useState(false);

  useEffect(() => {
    const el = footerRef.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => { if (e.isIntersecting) { setVis(true); io.disconnect(); } },
      { threshold: 0.08 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);

  /* ── slide helpers ── */
  const fromLeft  = (delay: number): React.CSSProperties => ({
    opacity: vis ? 1 : 0,
    transform: vis ? "none" : "translateX(-36px)",
    transition: `opacity .7s cubic-bezier(.22,1,.36,1) ${delay}ms, transform .7s cubic-bezier(.22,1,.36,1) ${delay}ms`,
  });
  const fromRight = (delay: number): React.CSSProperties => ({
    opacity: vis ? 1 : 0,
    transform: vis ? "none" : "translateX(36px)",
    transition: `opacity .7s cubic-bezier(.22,1,.36,1) ${delay}ms, transform .7s cubic-bezier(.22,1,.36,1) ${delay}ms`,
  });
  const fromTop = (delay: number): React.CSSProperties => ({
    opacity: vis ? 1 : 0,
    transform: vis ? "none" : "translateY(-16px)",
    transition: `opacity .7s ease ${delay}ms, transform .7s ease ${delay}ms`,
  });

  return (
    <>
      <style>{`
        .ft-root{ font-family: Archivo, Inter, sans-serif; }
        .ft-root *{ box-sizing: border-box; }
        .ft-navlink{
          display: flex; align-items: center; gap: 12px;
          font-family: Archivo, sans-serif;
          font-size: clamp(1rem,1.7vw,1.48rem);
          font-weight: 800; color: rgba(255,255,255,.82);
          text-decoration: none; letter-spacing: -.01em;
          padding: 9px 0;
          border-bottom: 1px solid rgba(255,255,255,.07);
          transition: color .2s ease;
        }
        .ft-navlink:hover{ color: ${RED_HX}; }
        .ft-social{ color: rgba(255,255,255,.42); text-decoration: none;
          font-family: ${MONO}; font-size: .78rem; font-weight: 700;
          letter-spacing: .18em; display: block; padding: 10px 0;
          border-bottom: 1px solid rgba(255,255,255,.07);
          text-align: right; transition: color .2s ease; }
        .ft-social:hover{ color: ${RED_HX}; }
        .ft-sub-input::placeholder{ color: rgba(255,255,255,.32); }
        @media(max-width: 800px){
          .ft-body{ grid-template-columns: 1fr !important; padding: 0 20px !important; }
          .ft-center{ display: none !important; }
          .ft-right{ align-items: flex-start !important; }
          .ft-social{ text-align: left !important; }
          .ft-bottom{ flex-direction: column; gap: 8px !important; padding: 14px 20px !important; }
          .ft-subscribe{ padding: 18px 20px !important; }
        }
      `}</style>

      <footer
        ref={footerRef}
        className="ft-root"
        style={{ position: "relative", background: "#080809", overflow: "hidden", minHeight: "88vh", display: "flex", flexDirection: "column" }}
      >
        {/* Starfield */}
        <StarField />

        {/* Scan-line overlay */}
        <div style={{ position: "absolute", inset: 0, backgroundImage: "repeating-linear-gradient(0deg,transparent,transparent 2px,rgba(255,255,255,.011) 3px)", pointerEvents: "none", zIndex: 1 }} />

        {/* Red radial glow — bottom centre */}
        <div style={{ position: "absolute", bottom: "-12%", left: "50%", transform: "translateX(-50%)", width: 720, height: 520, borderRadius: "50%", background: "radial-gradient(ellipse at center,rgba(200,18,31,.26) 0%,transparent 68%)", pointerEvents: "none", zIndex: 1 }} />

        {/* ── SUBSCRIBE BAR ── */}
        <div
          className="ft-subscribe"
          style={{
            position: "relative", zIndex: 3,
            borderBottom: "1px solid rgba(255,255,255,.07)",
            padding: "26px 48px",
            display: "flex", flexDirection: "column", alignItems: "center", gap: 12,
            ...fromTop(0),
          }}
        >
          <p style={{ fontFamily: MONO, fontSize: ".7rem", letterSpacing: ".22em", textTransform: "uppercase", color: "rgba(255,255,255,.48)", margin: 0 }}>
            Stay up to date with our latest offers and tyre tips
          </p>
          <div style={{ display: "flex", width: "100%", maxWidth: 600, border: "1.5px solid rgba(255,255,255,.16)", borderRadius: 40, overflow: "hidden", background: "rgba(255,255,255,.04)", backdropFilter: "blur(6px)" }}>
            <input
              type="email"
              value={email}
              onChange={e => { setEmail(e.target.value); setSubOk(false); }}
              placeholder="ENTER YOUR EMAIL"
              className="ft-sub-input"
              style={{ flex: 1, background: "transparent", border: "none", outline: "none", padding: "15px 22px", color: "#fff", fontFamily: MONO, fontSize: ".75rem", letterSpacing: ".13em" }}
            />
            <button
              onClick={() => { if (email) { setSubOk(true); setEmail(""); } }}
              style={{ background: subOk ? "#1a7a3c" : RED, color: "#fff", border: "none", padding: "0 26px", fontFamily: MONO, fontSize: ".75rem", fontWeight: 700, letterSpacing: ".17em", cursor: "pointer", transition: "background .3s ease", whiteSpace: "nowrap", flexShrink: 0 }}
            >
              {subOk ? "✓ DONE" : "SUBSCRIBE"}
            </button>
          </div>
        </div>

        {/* ── MAIN 3-COLUMN BODY ── */}
        <div
          className="ft-body"
          style={{ position: "relative", zIndex: 3, flex: 1, display: "grid", gridTemplateColumns: "1fr auto 1fr", alignItems: "end", padding: "0 48px", minHeight: 500 }}
        >

          {/* LEFT — logo + nav links */}
          <nav style={{ paddingBottom: 56, display: "flex", flexDirection: "column" }}>

            {/* Logo block */}
            <div style={{ marginBottom: 32, ...fromLeft(80) }}>
              <Logo size={36} />
              <div style={{ fontFamily: MONO, fontSize: ".6rem", letterSpacing: ".22em", color: "rgba(255,255,255,.32)", marginTop: 10, textTransform: "uppercase" }}>
                {COMPANY.tagline}
              </div>
            </div>

            {/* Quick links from FOOTER_LINKS */}
            {FOOTER_LINKS.map((link, i) => (
              <Link
                key={link.label}
                to={link.to}
                className="ft-navlink"
                style={{
                  ...fromLeft(160 + i * 75),
                }}
              >
                <span style={{ fontFamily: MONO, fontSize: ".58rem", color: RED, opacity: .75, minWidth: 20 }}>
                  {String(i + 1).padStart(2, "0")}
                </span>
                {link.label.toUpperCase()}
              </Link>
            ))}

            {/* Social icons */}
            <div style={{ marginTop: 28, ...fromLeft(160 + FOOTER_LINKS.length * 75) }}>
              <SocialIcons />
            </div>
          </nav>

          {/* CENTER — tyre glyph */}
          <div
            className="ft-center"
            style={{
              width: "clamp(260px,28vw,440px)",
              alignSelf: "flex-end",
              opacity: vis ? 1 : 0,
              transform: vis ? "translateY(0)" : "translateY(70px)",
              transition: "opacity 1s ease 260ms, transform 1.1s cubic-bezier(.22,1,.36,1) 260ms",
              pointerEvents: "none",
            }}
          >
            <TyreGlyph />
          </div>

          {/* RIGHT — contact details */}
          <div
            className="ft-right"
            style={{ paddingBottom: 56, display: "flex", flexDirection: "column", alignItems: "flex-end" }}
          >
            {/* CONTACT_ITEMS */}
            {CONTACT_ITEMS.map((item, i) => (
              <div
                key={item.label}
                style={{
                  display: "flex", alignItems: "center", gap: 14,
                  justifyContent: "flex-end",
                  marginBottom: 26,
                  ...fromRight(200 + i * 90),
                }}
              >
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontFamily: "Archivo, sans-serif", fontSize: i === 0 ? "clamp(1.2rem,2vw,1.85rem)" : ".95rem", fontWeight: i === 0 ? 900 : 700, color: "#fff", lineHeight: 1.2 }}>
                    {item.value}
                  </div>
                  {i > 0 && (
                    <div style={{ fontFamily: MONO, fontSize: ".6rem", letterSpacing: ".1em", color: "rgba(255,255,255,.35)", marginTop: 2, textTransform: "uppercase" }}>
                      {item.label}
                    </div>
                  )}
                </div>
                <div style={{ width: 40, height: 40, borderRadius: "50%", border: "1.5px solid rgba(255,255,255,.18)", display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,.65)", flexShrink: 0 }}>
                  {item.icon}
                </div>
              </div>
            ))}

            {/* Social labels (text links) */}
            {["INSTAGRAM", "FACEBOOK", "WHATSAPP"].map((s, i) => (
              <a
                key={s}
                href="#"
                className="ft-social"
                style={{
                  width: "100%",
                  ...fromRight(440 + i * 80),
                }}
              >
                {s}
              </a>
            ))}
          </div>
        </div>

        {/* ── BOTTOM BAR ── */}
        <div
          className="ft-bottom"
          style={{
            position: "relative", zIndex: 3,
            borderTop: "1px solid rgba(255,255,255,.07)",
            padding: "17px 48px",
            display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8,
            opacity: vis ? 1 : 0,
            transition: "opacity .9s ease 700ms",
          }}
        >
          <span style={{ fontFamily: MONO, fontSize: ".6rem", letterSpacing: ".13em", color: "rgba(255,255,255,.28)", textTransform: "uppercase" }}>
            © {new Date().getFullYear()} {COMPANY.fullName}. All rights reserved.
          </span>
          <div style={{ display: "flex", gap: 24 }}>
            <a href="#" style={{ fontFamily: MONO, fontSize: ".6rem", letterSpacing: ".13em", color: "rgba(255,255,255,.28)", textDecoration: "none", textTransform: "uppercase" }}>Privacy Policy</a>
            <a href="#" style={{ fontFamily: MONO, fontSize: ".6rem", letterSpacing: ".13em", color: "rgba(255,255,255,.28)", textDecoration: "none", textTransform: "uppercase" }}>Terms of Service</a>
          </div>
          <span style={{ fontFamily: MONO, fontSize: ".6rem", letterSpacing: ".13em", color: "rgba(255,255,255,.28)", textTransform: "uppercase" }}>
            Made with ♥ in Jammu
          </span>
        </div>
      </footer>
    </>
  );
}
