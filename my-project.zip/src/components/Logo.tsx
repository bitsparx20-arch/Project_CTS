import { Link } from "react-router-dom";
import { ROUTES } from "../config/site";

interface LogoProps {
  height?: number;
}

export default function Logo({
  height = 100,
}: LogoProps) {
  return (
    <Link
      to={ROUTES.home}
      className="brand-logo"
      aria-label="CTS Home"
    >
      <img
        src="/ctslogo.png"
        alt="CTS Tyres"
        className="brand-logo-image"
        style={{ height }}
      />
    </Link>
  );
}