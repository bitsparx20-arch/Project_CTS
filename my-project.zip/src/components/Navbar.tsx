import { useState, useEffect } from "react";
import { NavLink, useLocation } from "react-router-dom";
import Logo from "./Logo";
import { NAV_LINKS, ROUTES } from "../config/site";

/* ─── Home.tsx colour tokens ─── */
const T = {
  bg:       "#050505",
  hairline: "rgba(212,168,67,0.18)",

  text:     "#F5F0E8",
  muted:    "#8C8878",

  accent:   "#D4A843",

  /* CTS Colours */
  gradCyan: "#D4A843",
  gradPink: "#6BA84F",

  display:  "'Aspekta','Oswald',sans-serif",
};


const styles = `
  @import url('https://fonts.googleapis.com/css2?family=Oswald:wght@400;500;600;700&display=swap');

  /* ── Base nav shell ── */
  .cts-nav {
    position: fixed;
    top: 0; left: 0; right: 0;
    z-index: 1000;
    transition: background 0.35s ease, backdrop-filter 0.35s ease, border-color 0.35s ease;
  }

  /* Transparent at top */
  .cts-nav.is-top {
    background: transparent;
    border-bottom: 1px solid transparent;
    backdrop-filter: none;
  }

  /* Frosted once scrolled */
  .cts-nav.is-scrolled {
    background: rgba(5,5,5,0.88);
    border-bottom: 1px solid rgba(255,255,255,0.08);
    backdrop-filter: blur(18px) saturate(160%);
    -webkit-backdrop-filter: blur(18px) saturate(160%);
  }

  .cts-nav-inner {
    max-width: 1400px;
    margin: 0 auto;
    padding: 0 clamp(20px,4vw,56px);
    height: 76px;
    display: flex;
    align-items: center;
    gap: 0;
  }

  /* ── Logo slot ── */
  .cts-nav-logo {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    text-decoration: none;
  }

  /* ── Links (centre) ── */
  .cts-nav-links {
    display: flex;
    align-items: center;
    gap: clamp(20px,3vw,48px);
    list-style: none;
    margin: 0;
    padding: 0;
    flex: 1;
    justify-content: center;
  }

  .cts-nav-link {
    font-family: ${T.display};
    font-size: 11.5px;
    font-weight: 600;
    letter-spacing: 0.18em;
    text-transform: uppercase;
    color: rgba(255,255,255,0.72);
    text-decoration: none;
    position: relative;
    padding: 4px 0;
    white-space: nowrap;
    transition: color 0.2s ease;
  }

  /* Underline grow from centre */
  .cts-nav-link::after {
    content: '';
    position: absolute;
    bottom: -2px; left: 50%; right: 50%;
    height: 1px;
    background: linear-gradient(to right, ${T.gradCyan}, ${T.gradPink});
    transition: left 0.28s cubic-bezier(.22,1,.36,1), right 0.28s cubic-bezier(.22,1,.36,1);
  }

  .cts-nav-link:hover,
  .cts-nav-link.is-active {
    color: #fff;
  }
  .cts-nav-link:hover::after,
  .cts-nav-link.is-active::after {
    left: 0; right: 0;
  }

  .cts-nav-link.is-active {
    background: linear-gradient(to right, ${T.gradCyan}, ${T.gradPink});
    -webkit-background-clip: text;
    background-clip: text;
    -webkit-text-fill-color: transparent;
    color: transparent;
  }

  /* ── Right slot ── */
  .cts-nav-right {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-shrink: 0;
  }

  /* Outline pill CTA — matches reference */
  .cts-nav-cta {
    font-family: ${T.display};
    font-size: 11px;
    font-weight: 700;
    letter-spacing: 0.2em;
    text-transform: uppercase;
    color: #fff;
    text-decoration: none;
    padding: 9px 22px;
    border-radius: 999px;
    border: 1px solid rgba(255,255,255,0.45);
    background: transparent;
    transition: background 0.2s, border-color 0.2s, box-shadow 0.2s, color 0.2s;
    white-space: nowrap;
  }
  .cts-nav-cta:hover {
    background: ${T.accent};
    border-color: ${T.accent};
    color: #fff;
    box-shadow: 0 0 24px rgba(224,36,36,0.45);
  }

  /* ── Hamburger ── */
  .cts-nav-toggle {
    display: none;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    gap: 5px;
    width: 40px;
    height: 40px;
    background: none;
    border: 1px solid ${T.hairline};
    border-radius: 8px;
    cursor: pointer;
    padding: 0;
    flex-shrink: 0;
  }
  .cts-nav-toggle span {
    display: block;
    width: 20px;
    height: 1.5px;
    background: #fff;
    border-radius: 2px;
    transition: transform 0.3s ease, opacity 0.3s ease;
    transform-origin: center;
  }
  .cts-nav-toggle.is-open span:nth-child(1) { transform: translateY(6.5px) rotate(45deg); }
  .cts-nav-toggle.is-open span:nth-child(2) { opacity: 0; transform: scaleX(0); }
  .cts-nav-toggle.is-open span:nth-child(3) { transform: translateY(-6.5px) rotate(-45deg); }

  /* ── Mobile drawer ── */
  @media (max-width: 860px) {
    .cts-nav-toggle { display: flex; }
    .cts-nav-links  { display: none; }

    .cts-nav-right {
      position: fixed;
      top: 76px; left: 0; right: 0;
      flex-direction: column;
      align-items: stretch;
      gap: 0;
      background: rgba(5,5,5,0.97);
      backdrop-filter: blur(20px);
      border-bottom: 1px solid ${T.hairline};
      padding: 20px 24px 28px;
      transform: translateY(-110%);
      opacity: 0;
      pointer-events: none;
      transition: transform 0.38s cubic-bezier(.22,1,.36,1), opacity 0.38s;
    }
    .cts-nav-right.is-open {
      transform: translateY(0);
      opacity: 1;
      pointer-events: all;
    }

    /* Show links inside the drawer on mobile */
    .cts-nav-right .cts-nav-links-mobile {
      display: flex;
      flex-direction: column;
      gap: 0;
      list-style: none;
      margin: 0 0 20px;
      padding: 0;
      border-bottom: 1px solid ${T.hairline};
      padding-bottom: 20px;
    }
    .cts-nav-right .cts-nav-links-mobile li a {
      font-family: ${T.display};
      font-size: 13px;
      font-weight: 600;
      letter-spacing: 0.14em;
      text-transform: uppercase;
      color: rgba(255,255,255,0.72);
      text-decoration: none;
      display: block;
      padding: 13px 0;
      border-bottom: 1px solid rgba(255,255,255,0.05);
      transition: color 0.2s;
    }
    .cts-nav-right .cts-nav-links-mobile li a:hover,
    .cts-nav-right .cts-nav-links-mobile li a.is-active {
      color: #fff;
    }

    .cts-nav-cta {
      text-align: center;
      padding: 14px 22px;
    }
  }

  @media (min-width: 861px) {
    .cts-nav-links-mobile { display: none !important; }
  }
`;

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const [scrolled, setScrolled]  = useState(false);
  const location = useLocation();
  const closeMenu = () => setMenuOpen(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll, { passive: true });
    onScroll();
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close drawer on route change
  useEffect(() => { closeMenu(); }, [location.pathname]);

  return (
    <>
      <style>{styles}</style>

      <nav className={`cts-nav ${scrolled ? "is-scrolled" : "is-top"}`} role="navigation" aria-label="Main navigation">
        <div className="cts-nav-inner">

          {/* Logo */}
          <NavLink to={ROUTES.home} className="cts-nav-logo" onClick={closeMenu} aria-label="CTS Tyres — home">
            <Logo size={36} textSize={22} />
          </NavLink>

          {/* Desktop nav links — centred */}
          <ul className="cts-nav-links">
            {NAV_LINKS.map((item) => (
              <li key={item.to}>
                <NavLink
                  to={item.to}
                  end={item.to === ROUTES.home}
                  className={({ isActive }) => `cts-nav-link${isActive ? " is-active" : ""}`}
                  onClick={closeMenu}
                >
                  {item.label}
                </NavLink>
              </li>
            ))}
          </ul>

          {/* Right — CTA + hamburger */}
          <div className={`cts-nav-right${menuOpen ? " is-open" : ""}`}>
            {/* Mobile-only links inside drawer */}
            <ul className="cts-nav-links-mobile">
              {NAV_LINKS.map((item) => (
                <li key={item.to}>
                  <NavLink
                    to={item.to}
                    end={item.to === ROUTES.home}
                    className={({ isActive }) => isActive ? "is-active" : ""}
                    onClick={closeMenu}
                  >
                    {item.label}
                  </NavLink>
                </li>
              ))}
            </ul>

            {/* CTA pill */}
            {/* <NavLink to={ROUTES.tyres} className="cts-nav-cta" onClick={closeMenu}> */}
              {/* Find My Tyre */}
            {/* </NavLink> */}
           </div> 

          {/* Hamburger */}
          <button
            type="button"
            className={`cts-nav-toggle${menuOpen ? " is-open" : ""}`}
            aria-label="Toggle navigation menu"
            aria-expanded={menuOpen}
            onClick={() => setMenuOpen((o) => !o)}
          >
            <span />
            <span />
            <span />
          </button>

        </div>
      </nav>
    </>
  );
}