import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { ROUTES, COMPANY } from "../config/site";

/* ============================================================================
   TOKENS — same palette as About but used differently
   ========================================================================== */
const T = {
  bg:       "#0C0D08",
  paper:    "#F5F0E8",   // warm cream — used as a SECTION BG (About never uses this)
  ink:      "#F5F0E8",
  inkDark:  "#1A1B14",   // dark ink for use on cream bg
  inkDim:   "#8C8878",
  amber:    "#D4A843",
  amberDim: "#A07A20",
  green:    "#3D5A2E",
  greenBrt: "#6BA84F",
  rust:     "#B84A2C",
  hairline: "rgba(212,168,67,0.18)",
  hairlineDark: "rgba(26,27,20,0.15)",
  mono:     "'Space Mono',monospace",
  display:  "'Archivo',sans-serif",
  body:     "'Archivo',sans-serif",
};

/* ============================================================================
   GLOBAL CSS  — different class prefix (cx-) from AboutUs (au-)
   ========================================================================== */
const CSS = `
  @import url('https://fonts.googleapis.com/css2?family=Archivo:wght@300;400;500;600;700;800;900&family=Space+Mono:wght@400;700&display=swap');
  .cx-root *{ box-sizing:border-box; }
  ::selection{ background:#D4A843; color:#0C0D08; }

  @keyframes cx-up    { from{opacity:0;transform:translateY(24px)} to{opacity:1;transform:none} }
  @keyframes cx-left  { from{opacity:0;transform:translateX(-22px)} to{opacity:1;transform:none} }
  @keyframes cx-right { from{opacity:0;transform:translateX(22px)} to{opacity:1;transform:none} }
  @keyframes cx-scale { from{opacity:0;transform:scale(.94)} to{opacity:1;transform:scale(1)} }
  @keyframes cx-glow  { 0%,100%{opacity:.28} 50%{opacity:.8} }
  @keyframes cx-spin  { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
  @keyframes cx-pulse { 0%,100%{transform:scale(1)} 50%{transform:scale(1.06)} }
  @keyframes cx-shine { 0%{left:-60%} 100%{left:110%} }
  @keyframes cx-count { from{opacity:0;transform:scale(.7) translateY(8px)} to{opacity:1;transform:scale(1) translateY(0)} }
  @keyframes cx-blink { 0%,100%{opacity:1} 50%{opacity:0} }
  @keyframes cx-rail  { from{transform:translateY(0)} to{transform:translateY(-50%)} }
  @keyframes cx-draw  { from{stroke-dashoffset:1000} to{stroke-dashoffset:0} }

  /* reveal */
  .cx-rv { opacity:0; }
  .cx-rv.on  { animation:cx-up    .7s cubic-bezier(.22,1,.36,1) both; }
  .cx-rvL.on { animation:cx-left  .7s cubic-bezier(.22,1,.36,1) both; }
  .cx-rvR.on { animation:cx-right .7s cubic-bezier(.22,1,.36,1) both; }
  .cx-rvS.on { animation:cx-scale .7s cubic-bezier(.22,1,.36,1) both; }

  /* vertical rail ticker */
  .cx-vrail { display:flex; flex-direction:column; gap:32px; animation:cx-rail 22s linear infinite; }

  /* form inputs — cream bg version */
  .cx-field {
    border:none; border-bottom:1px solid ${T.hairlineDark};
    background:transparent; outline:none;
    font-family:'Archivo',sans-serif; font-size:1rem; font-weight:500;
    color:${T.inkDark}; padding:14px 0; width:100%;
    transition:border-color .25s;
  }
  .cx-field:focus { border-color:#D4A843; }
  .cx-field::placeholder { color:rgba(26,27,20,.35); font-weight:400; }
  .cx-field-wrap { position:relative; margin-bottom:28px; }
  .cx-field-wrap::after {
    content:''; position:absolute; bottom:0; left:0; width:0; height:1px;
    background:#D4A843; transition:width .35s cubic-bezier(.22,1,.36,1);
  }
  .cx-field-wrap:focus-within::after { width:100%; }
  .cx-flabel {
    display:block; font-family:'Space Mono',monospace; font-size:.58rem;
    font-weight:700; letter-spacing:.22em; text-transform:uppercase;
    color:rgba(26,27,20,.4); margin-bottom:4px;
  }
  .cx-field select { cursor:pointer; }
  .cx-field option { background:#F5F0E8; color:#1A1B14; }

  /* submit */
  .cx-submit {
    position:relative; overflow:hidden;
    background:#1A1B14; color:#D4A843;
    border:none; cursor:pointer; font-family:'Archivo',sans-serif;
    font-size:.92rem; font-weight:800; letter-spacing:.06em;
    padding:18px 0; width:100%; border-radius:2px;
    transition:background .25s, color .25s, box-shadow .25s;
  }
  .cx-submit:hover { background:#D4A843; color:#1A1B14; box-shadow:0 8px 28px rgba(212,168,67,.35); }
  .cx-submit::after {
    content:''; position:absolute; top:-50%; left:-60%;
    width:200%; height:200%;
    background:linear-gradient(45deg,transparent,rgba(255,255,255,.12),transparent);
    transform:rotate(45deg); animation:cx-shine 3s ease-in-out infinite;
  }

  /* bento cards */
  .cx-bento {
    border:1px solid rgba(26,27,20,.1); border-radius:2px;
    transition:border-color .25s, box-shadow .3s, transform .3s cubic-bezier(.22,1,.36,1);
    cursor:default;
  }
  .cx-bento:hover { border-color:rgba(212,168,67,.5); box-shadow:0 16px 48px rgba(212,168,67,.1); transform:translateY(-3px); }

  /* dot cursor blinking in hero */
  .cx-cursor { display:inline-block; animation:cx-blink 1.1s step-end infinite; }

  /* spinning ring around number */
  .cx-ring { animation:cx-spin 12s linear infinite; }

  /* stat number pop */
  .cx-stat-num.on { animation:cx-count .55s cubic-bezier(.22,1,.36,1) both; }

  /* nav pill active */
  .cx-nav-pill {
    font-family:'Space Mono',monospace; font-size:.6rem; font-weight:700;
    letter-spacing:.16em; text-transform:uppercase; padding:7px 14px;
    border-radius:999px; border:1px solid rgba(212,168,67,.25);
    color:rgba(245,240,232,.45); background:transparent; cursor:pointer;
    transition:all .2s ease;
  }
  .cx-nav-pill.active, .cx-nav-pill:hover {
    border-color:#D4A843; color:#D4A843; background:rgba(212,168,67,.08);
  }

  @media(max-width:960px){
    .cx-hero-num  { font-size:clamp(5rem,18vw,10rem) !important; }
    .cx-bento-row { grid-template-columns:1fr !important; }
    .cx-form-sec  { grid-template-columns:1fr !important; }
    .cx-form-cols { grid-template-columns:1fr !important; }
    .cx-rail-col  { display:none !important; }
    .cx-hero-pad  { padding:80px 24px 56px !important; }
    .cx-bar       { flex-wrap:wrap; gap:12px !important; }
  }
  @media(max-width:600px){
    .cx-hero-pad  { padding:72px 18px 44px !important; }
    .cx-sec-pad   { padding-left:20px !important; padding-right:20px !important; }
    .cx-footer-row{ flex-direction:column !important; align-items:flex-start !important; gap:16px !important; }
  }
`;

/* ============================================================================
   HOOKS
   ========================================================================== */
function useOnScreen(threshold = 0.12) {
  const ref = useRef<HTMLDivElement>(null);
  const [on, setOn] = useState(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setOn(true); io.disconnect(); } }, { threshold });
    io.observe(el); return () => io.disconnect();
  }, [threshold]);
  return { ref, on };
}

function Rev({ children, cls = "cx-rv", delay = 0, style = {} }: { children: React.ReactNode; cls?: string; delay?: number; style?: React.CSSProperties }) {
  const { ref, on } = useOnScreen();
  return <div ref={ref} className={`${cls}${on ? " on" : ""}`} style={{ animationDelay: `${delay}ms`, ...style }}>{children}</div>;
}

/* ============================================================================
   COUNT-UP (reused)
   ========================================================================== */
function Count({ to, suffix }: { to: number; suffix: string }) {
  const ref = useRef<HTMLSpanElement>(null);
  const [n, setN] = useState(0);
  const done = useRef(false);
  useEffect(() => {
    const el = ref.current; if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting && !done.current) {
        done.current = true;
        const t0 = performance.now(), dur = 1600;
        const tick = (t: number) => { const p = Math.min(1, (t - t0) / dur); setN(Math.floor(to * (1 - Math.pow(1 - p, 3)))); if (p < 1) requestAnimationFrame(tick); };
        requestAnimationFrame(tick); io.disconnect();
      }
    }, { threshold: 0.5 });
    io.observe(el); return () => io.disconnect();
  }, [to]);
  return <span ref={ref}>{n.toLocaleString("en-US")}{suffix}</span>;
}

/* ============================================================================
   ICONS
   ========================================================================== */
const svgP = { viewBox:"0 0 24 24", fill:"none", stroke:"currentColor", strokeWidth:1.6, strokeLinecap:"round" as const, strokeLinejoin:"round" as const };
const IPhone  = ()=><svg {...svgP} width={20} height={20}><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.82 19.79 19.79 0 01-.001 1.2 2 2 0 012 0h3a2 2 0 012 1.72 12.84 12.84 0 00.7 2.81 2 2 0 01-.45 2.11L6.09 7.91a16 16 0 006 6l1.27-1.27a2 2 0 012.11-.45 12.84 12.84 0 002.81.7A2 2 0 0122 16.92z"/></svg>;
const IMail   = ()=><svg {...svgP} width={20} height={20}><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><path d="M22 6l-10 7L2 6"/></svg>;
const IPin    = ()=><svg {...svgP} width={20} height={20}><path d="M21 10c0 7-9 13-9 13S3 17 3 10a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/></svg>;
const IClock  = ()=><svg {...svgP} width={20} height={20}><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>;
const IArrow  = ()=><svg {...svgP} width={16} height={16}><path d="M7 17l5-5-5-5"/><path d="M4 12h8"/></svg>;
const ICheck  = ()=><svg {...svgP} width={22} height={22}><path d="M20 6L9 17l-5-5"/></svg>;
const IWrench = ()=><svg {...svgP} width={20} height={20}><path d="M14.7 6.3a1 1 0 000 1.4l1.6 1.6a1 1 0 001.4 0l3.77-3.77a6 6 0 01-7.94 7.94l-6.91 6.91a2.12 2.12 0 01-3-3l6.91-6.91a6 6 0 017.94-7.94l-3.76 3.76z"/></svg>;
const ITyre   = ()=><svg {...svgP} width={20} height={20}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="4"/><path d="M12 3v2M12 19v2M3 12h2M19 12h2"/></svg>;
const IStar   = ()=><svg {...svgP} width={20} height={20}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>;

/* ============================================================================
   VERTICAL RAIL — left side ambient text strip (unique to Contact)
   ========================================================================== */
const RAIL_ITEMS = ["WHEEL ALIGNMENT","BALANCING","FITMENT","INSPECTION","ROTATION","REPLACEMENT","NITROGEN","PERFORMANCE","FLEET","PUNCTURE REPAIR"];
function VerticalRail() {
  const doubled = [...RAIL_ITEMS, ...RAIL_ITEMS];
  return (
    <div style={{ position:"fixed", left:0, top:0, bottom:0, width:40, overflow:"hidden", zIndex:50, pointerEvents:"none", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <div className="cx-vrail">
        {doubled.map((item, i) => (
          <span key={i} style={{ fontFamily:T.mono, fontSize:8, fontWeight:700, letterSpacing:".3em", textTransform:"uppercase", color:"rgba(212,168,67,.18)", writingMode:"vertical-rl", transform:"rotate(180deg)", whiteSpace:"nowrap" }}>
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

/* ============================================================================
   HERO — number-first / editorial index style
   Completely different from About: amber number "01" dominates left,
   right side has contact info cards stacked vertically
   ========================================================================== */
function Hero() {
  const [tick, setTick] = useState(0);
  useEffect(() => { const id = setInterval(() => setTick(t => t + 1), 1000); return () => clearInterval(id); }, []);
  const now = new Date();
  const timeStr = now.toLocaleTimeString("en-IN", { hour:"2-digit", minute:"2-digit", second:"2-digit", hour12:false });

  return (
    <section style={{ position:"relative", background:T.bg, overflow:"hidden", minHeight:"100vh", display:"flex", flexDirection:"column" }}>
      {/* Horizontal amber rule at 50% */}
      <div style={{ position:"absolute", top:"50%", left:40, right:0, height:1, background:`linear-gradient(to right,${T.amber}55,transparent 80%)`, pointerEvents:"none", zIndex:1 }}/>
      {/* vertical amber rule at 48% */}
      <div style={{ position:"absolute", left:"48%", top:0, bottom:0, width:1, background:`linear-gradient(to bottom,transparent,${T.amber}33 30%,${T.amber}33 70%,transparent)`, pointerEvents:"none", zIndex:1 }}/>

      {/* Dot grid texture */}
      <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle, rgba(212,168,67,.12) 1px, transparent 1px)`, backgroundSize:"40px 40px", pointerEvents:"none", zIndex:0 }}/>

      {/* Radial amber glow bottom-left */}
      <div style={{ position:"absolute", bottom:"-20%", left:"10%", width:500, height:500, borderRadius:"50%", background:`radial-gradient(circle,${T.amber}18,transparent 65%)`, filter:"blur(60px)", animation:"cx-glow 6s ease-in-out infinite", pointerEvents:"none" }}/>
      {/* Green glow top-right */}
      <div style={{ position:"absolute", top:"-10%", right:"5%", width:400, height:400, borderRadius:"50%", background:`radial-gradient(circle,${T.greenBrt}12,transparent 65%)`, filter:"blur(70px)", animation:"cx-glow 8s ease-in-out infinite .6s", pointerEvents:"none" }}/>

      <div className="cx-hero-pad" style={{ position:"relative", zIndex:2, flex:1, padding:"clamp(80px,10vh,120px) clamp(28px,5vw,72px) clamp(56px,6vh,88px) 56px", display:"grid", gridTemplateColumns:"1fr 1fr", gap:0, alignItems:"center" }}>

        {/* LEFT — giant index number + title */}
        <div style={{ paddingRight:48 }}>
          {/* Overline */}
          <motion.div initial={{opacity:0,x:-20}} animate={{opacity:1,x:0}} transition={{delay:.06,duration:.5,ease:[.22,1,.36,1]}}
            style={{ display:"flex", alignItems:"center", gap:12, marginBottom:16 }}>
            <div style={{ width:8, height:8, borderRadius:"50%", background:T.amber, animation:"cx-pulse 2s ease-in-out infinite" }}/>
            <span style={{ fontFamily:T.mono, fontSize:10, letterSpacing:".35em", textTransform:"uppercase", color:T.amber, fontWeight:700 }}>Contact CTS Tyres</span>
          </motion.div>

          {/* Giant number */}
          <div style={{ position:"relative", marginBottom:8 }}>
            <motion.div initial={{opacity:0,scale:.8}} animate={{opacity:1,scale:1}} transition={{delay:.14,duration:.7,ease:[.22,1,.36,1]}}>
              <span className="cx-hero-num" style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(7rem,18vw,16rem)", lineHeight:.82, letterSpacing:"-.06em", color:"transparent", WebkitTextStroke:`1.5px ${T.amber}`, display:"block" }}>01</span>
            </motion.div>
            {/* Spinning ring around number */}
            <div className="cx-ring" style={{ position:"absolute", top:"50%", left:"12%", transform:"translate(-50%,-50%)", width:"min(200px,22vw)", height:"min(200px,22vw)", borderRadius:"50%", border:`1px dashed rgba(212,168,67,.22)`, pointerEvents:"none" }}/>
          </div>

          {/* Heading */}
          <div style={{ overflow:"hidden", marginBottom:6 }}>
            <motion.h1 initial={{y:"105%"}} animate={{y:0}} transition={{delay:.22,duration:.72,ease:[.22,1,.36,1]}}
              style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(2rem,4.5vw,4rem)", lineHeight:.95, letterSpacing:"-.035em", textTransform:"uppercase", color:T.ink, margin:0 }}>
              GET IN TOUCH
            </motion.h1>
          </div>
          <div style={{ overflow:"hidden", marginBottom:28 }}>
            <motion.h1 initial={{y:"105%"}} animate={{y:0}} transition={{delay:.3,duration:.72,ease:[.22,1,.36,1]}}
              style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(2rem,4.5vw,4rem)", lineHeight:.95, letterSpacing:"-.035em", textTransform:"uppercase", color:T.amber, margin:0 }}>
              WITH US.<span className="cx-cursor" style={{ color:T.green }}>_</span>
            </motion.h1>
          </div>

          <motion.p initial={{opacity:0,y:12}} animate={{opacity:1,y:0}} transition={{delay:.42,duration:.55,ease:[.22,1,.36,1]}}
            style={{ fontFamily:T.body, fontSize:"clamp(.9rem,1.1vw,1.02rem)", color:T.inkDim, lineHeight:1.72, maxWidth:360, margin:"0 0 32px", fontWeight:300 }}>
            Walk in without an appointment, send a message, or call — we respond the same day.
          </motion.p>

          {/* Live clock */}
          <motion.div initial={{opacity:0}} animate={{opacity:1}} transition={{delay:.55,duration:.5}}
            style={{ display:"inline-flex", alignItems:"center", gap:10, padding:"8px 16px", border:`1px solid ${T.hairline}`, borderRadius:999, background:"rgba(212,168,67,.06)" }}>
            <div style={{ width:6, height:6, borderRadius:"50%", background:T.greenBrt, animation:"cx-pulse 1.5s ease-in-out infinite" }}/>
            <span style={{ fontFamily:T.mono, fontSize:".65rem", color:T.amber, letterSpacing:".14em" }}>LIVE · {timeStr} IST</span>
          </motion.div>
        </div>

        {/* RIGHT — stacked contact fact cards */}
        <div style={{ display:"flex", flexDirection:"column", gap:14, paddingLeft:48, borderLeft:`1px solid ${T.hairline}` }}>
          {[
            { icon:<IPhone/>, label:"Call us", value:COMPANY.phone??"98765 43210", sub:"Mon–Sun · Same day response", href:COMPANY.phoneHref??"tel:+91", delay:0.28 },
            { icon:<IMail/>,  label:"Email",   value:"hello@ctstyres.com", sub:"Response within hours", href:"mailto:hello@ctstyres.com", delay:0.36 },
            { icon:<IPin/>,   label:"Visit us", value:"123 Tyre Lane, Mumbai", sub:"MH 400001 · Walk-ins welcome", href:"#", delay:0.44 },
            { icon:<IClock/>, label:"Hours",   value:"Mon–Sat 8am–7pm", sub:"Sunday 9am–5pm", href:null, delay:0.52 },
          ].map((card) => (
            <motion.div key={card.label} initial={{opacity:0,x:24}} animate={{opacity:1,x:0}} transition={{delay:card.delay,duration:.55,ease:[.22,1,.36,1]}}>
              {card.href ? (
                <a href={card.href} style={{ textDecoration:"none", display:"block" }}
                  onMouseEnter={e=>(e.currentTarget.style.borderColor=T.amber)}
                  onMouseLeave={e=>(e.currentTarget.style.borderColor=T.hairline)}>
                  <ContactCard icon={card.icon} label={card.label} value={card.value} sub={card.sub} />
                </a>
              ) : (
                <ContactCard icon={card.icon} label={card.label} value={card.value} sub={card.sub} />
              )}
            </motion.div>
          ))}

          {/* CTA */}
          <motion.a initial={{opacity:0,y:10}} animate={{opacity:1,y:0}} transition={{delay:.62,duration:.5,ease:[.22,1,.36,1]}}
            href="#form" className="cx-submit" style={{ display:"block", textAlign:"center", textDecoration:"none", marginTop:4 }}>
            Send a Message →
          </motion.a>
        </div>
      </div>

      {/* Bottom amber rule */}
      <div style={{ position:"absolute", bottom:0, left:40, right:0, height:2, background:`linear-gradient(to right,${T.amber}88,${T.greenBrt}44,transparent)`, zIndex:3 }}/>
    </section>
  );
}

function ContactCard({ icon, label, value, sub }: { icon:React.ReactNode; label:string; value:string; sub:string }) {
  return (
    <div style={{ display:"flex", alignItems:"flex-start", gap:14, padding:"16px 18px", background:"rgba(20,22,8,.8)", border:`1px solid ${T.hairline}`, borderRadius:6, backdropFilter:"blur(8px)", transition:"border-color .25s, background .25s" }}>
      <div style={{ width:38, height:38, borderRadius:8, background:`rgba(212,168,67,.1)`, border:`1px solid rgba(212,168,67,.22)`, display:"flex", alignItems:"center", justifyContent:"center", color:T.amber, flexShrink:0 }}>{icon}</div>
      <div>
        <p style={{ fontFamily:T.mono, fontSize:".56rem", letterSpacing:".2em", textTransform:"uppercase", color:T.inkDim, margin:"0 0 3px" }}>{label}</p>
        <p style={{ fontFamily:T.display, fontWeight:700, fontSize:".92rem", color:T.ink, margin:"0 0 2px", letterSpacing:"-.01em" }}>{value}</p>
        <p style={{ fontFamily:T.mono, fontSize:".6rem", color:"rgba(140,136,120,.6)", margin:0, letterSpacing:".06em" }}>{sub}</p>
      </div>
    </div>
  );
}

/* ============================================================================
   BENTO INFO GRID — cream background section (About has no cream sections)
   3 wide + 1 tall layout
   ========================================================================== */
function BentoSection() {
  const services = ["Tyre Replacement","Wheel Balancing","3D Alignment","Rotation","Puncture Repair","Nitrogen Fill","Inspection","Performance","Fleet"];
  return (
    <section style={{ background:T.paper, position:"relative", overflow:"hidden", padding:"80px 56px 88px" }}>
      {/* diagonal stripe — different direction from About's (-45deg) */}
      <div style={{ position:"absolute", inset:0, backgroundImage:`repeating-linear-gradient(60deg,rgba(26,27,20,.05) 0,rgba(26,27,20,.05) 1px,transparent 1px,transparent 32px)`, pointerEvents:"none" }}/>
      <div style={{ position:"absolute", top:"-20%", right:"-10%", width:400, height:400, borderRadius:"50%", background:`radial-gradient(circle,rgba(212,168,67,.12),transparent 65%)`, filter:"blur(50px)", pointerEvents:"none", animation:"cx-glow 7s ease-in-out infinite" }}/>

      <div style={{ maxWidth:1240, margin:"0 auto", position:"relative", zIndex:1 }}>
        <Rev style={{ marginBottom:52 }}>
          <div style={{ display:"flex", alignItems:"flex-end", justifyContent:"space-between", flexWrap:"wrap", gap:16 }}>
            <div>
              <p style={{ fontFamily:T.mono, fontSize:".6rem", letterSpacing:".32em", textTransform:"uppercase", color:T.amber, fontWeight:700, margin:"0 0 10px" }}>[ 02 ] — What We Offer</p>
              <h2 style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(2rem,4vw,3.4rem)", color:T.inkDark, letterSpacing:"-.03em", lineHeight:.95, margin:0, textTransform:"uppercase" }}>
                Every service<br/>under one roof
              </h2>
            </div>
            <p style={{ fontFamily:T.body, fontSize:".95rem", color:"rgba(26,27,20,.55)", maxWidth:320, margin:0, lineHeight:1.7, fontWeight:300 }}>
              Nine specialist services — walk in or book ahead. Same-day turnaround on most jobs.
            </p>
          </div>
          {/* Amber underline rule */}
          <div style={{ width:"100%", height:1, background:`linear-gradient(to right,${T.amber}66,transparent)`, marginTop:28 }}/>
        </Rev>

        {/* Bento grid — asymmetric 3+1 */}
        <div className="cx-bento-row" style={{ display:"grid", gridTemplateColumns:"2fr 1fr 1fr", gridTemplateRows:"auto auto", gap:16 }}>
          {/* Wide card — services list */}
          <Rev cls="cx-rvL" style={{ gridRow:"1 / 3" }}>
            <div className="cx-bento" style={{ background:T.inkDark, padding:"40px 36px", height:"100%", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", bottom:-60, right:-60, width:220, height:220, borderRadius:"50%", background:`radial-gradient(circle,${T.amber}18,transparent 70%)`, pointerEvents:"none" }}/>
              <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".28em", textTransform:"uppercase", color:T.amber, margin:"0 0 20px" }}>All Services</p>
              <div style={{ display:"flex", flexDirection:"column", gap:0 }}>
                {services.map((s, i) => (
                  <div key={s} style={{ display:"flex", alignItems:"center", gap:14, padding:"13px 0", borderBottom:`1px solid rgba(212,168,67,.1)` }}>
                    <span style={{ fontFamily:T.mono, fontSize:".58rem", color:"rgba(212,168,67,.4)", minWidth:24 }}>{String(i+1).padStart(2,"0")}</span>
                    <span style={{ fontFamily:T.display, fontWeight:600, fontSize:".92rem", color:T.ink }}>{s}</span>
                    <div style={{ flex:1 }}/>
                    <span style={{ color:"rgba(212,168,67,.35)", fontSize:".7rem" }}>→</span>
                  </div>
                ))}
              </div>
            </div>
          </Rev>

          {/* Stat card — years */}
          <Rev delay={80}>
            <div className="cx-bento" style={{ background:T.amber, padding:"32px 28px", position:"relative", overflow:"hidden" }}>
              <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".22em", textTransform:"uppercase", color:T.inkDark, opacity:.6, margin:"0 0 12px" }}>Trusted Since</p>
              <div style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(3rem,6vw,5rem)", color:T.inkDark, lineHeight:.9, letterSpacing:"-.04em", marginBottom:8 }}>
                <Count to={12} suffix="+"/>
              </div>
              <p style={{ fontFamily:T.display, fontWeight:700, fontSize:".95rem", color:T.inkDark, margin:0, letterSpacing:"-.01em", textTransform:"uppercase" }}>Years of Excellence</p>
            </div>
          </Rev>

          {/* Stat card — tyres */}
          <Rev delay={140}>
            <div className="cx-bento" style={{ background:T.green, padding:"32px 28px", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", top:-20, right:-20, width:100, height:100, borderRadius:"50%", background:"rgba(245,240,232,.06)", pointerEvents:"none" }}/>
              <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".22em", textTransform:"uppercase", color:T.greenBrt, margin:"0 0 12px" }}>In Stock</p>
              <div style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(3rem,6vw,5rem)", color:T.ink, lineHeight:.9, letterSpacing:"-.04em", marginBottom:8 }}>
                <Count to={10000} suffix="+"/>
              </div>
              <p style={{ fontFamily:T.display, fontWeight:700, fontSize:".95rem", color:T.ink, margin:0, letterSpacing:"-.01em", textTransform:"uppercase" }}>Tyres Ready Now</p>
            </div>
          </Rev>

          {/* Stat card — brands */}
          <Rev delay={200}>
            <div className="cx-bento" style={{ background:"rgba(26,27,20,.04)", border:`1px solid ${T.hairlineDark}`, padding:"28px 26px" }}>
              <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".22em", textTransform:"uppercase", color:T.amber, margin:"0 0 10px" }}>Indian Brands</p>
              <div style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(2.4rem,5vw,4.2rem)", color:T.inkDark, lineHeight:.9, letterSpacing:"-.04em", marginBottom:8 }}>
                <Count to={10} suffix="+"/>
              </div>
              <p style={{ fontFamily:T.mono, fontSize:".62rem", color:"rgba(26,27,20,.45)", margin:0 }}>MRF · CEAT · Apollo · JK ·<br/>TVS · Birla & more</p>
            </div>
          </Rev>

          {/* "Walk-in" highlight card */}
          <Rev delay={260}>
            <div className="cx-bento" style={{ background:T.rust, padding:"28px 26px", position:"relative", overflow:"hidden" }}>
              <div style={{ position:"absolute", bottom:-30, right:-30, width:90, height:90, borderRadius:"50%", background:"rgba(245,240,232,.08)", pointerEvents:"none" }}/>
              <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".22em", textTransform:"uppercase", color:"rgba(245,240,232,.65)", margin:"0 0 10px" }}>No Appointment?</p>
              <p style={{ fontFamily:T.display, fontWeight:900, fontSize:"1.1rem", color:T.ink, margin:"0 0 8px", letterSpacing:"-.01em", textTransform:"uppercase", lineHeight:1.2 }}>Walk-ins<br/>Always Welcome</p>
              <Link to={ROUTES.contact ?? "#"} style={{ fontFamily:T.mono, fontSize:".6rem", color:T.ink, opacity:.7, textDecoration:"none", letterSpacing:".1em" }}>Visit us today →</Link>
            </div>
          </Rev>
        </div>
      </div>
    </section>
  );
}

/* ============================================================================
   FORM SECTION — dark + cream two-pane (full viewport feel)
   Form on right on cream background; left side is dark with big type
   ========================================================================== */
function FormSection() {
  const [step, setStep] = useState<"form"|"sent">("form");
  const [busy, setBusy] = useState(false);
  const [form, setForm] = useState({ name:"", phone:"", email:"", service:"", message:"", vehicle:"" });
  const up = (k: keyof typeof form) => (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => setForm(prev => ({ ...prev, [k]: e.target.value }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault(); setBusy(true);
    setTimeout(() => { setBusy(false); setStep("sent"); }, 1400);
  };

  return (
    <section id="form" style={{ position:"relative", overflow:"hidden" }}>
      <div className="cx-form-sec" style={{ display:"grid", gridTemplateColumns:"1fr 1.2fr", minHeight:"80vh" }}>

        {/* LEFT — dark panel with large typography */}
        <div style={{ background:T.inkDark, position:"relative", overflow:"hidden", padding:"64px 52px", display:"flex", flexDirection:"column", justifyContent:"space-between" }}>
          {/* dot grid */}
          <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle,rgba(212,168,67,.1) 1px,transparent 1px)`, backgroundSize:"36px 36px", pointerEvents:"none" }}/>
          <div style={{ position:"absolute", bottom:"-20%", left:"-10%", width:350, height:350, borderRadius:"50%", background:`radial-gradient(circle,${T.amber}18,transparent 70%)`, filter:"blur(50px)", pointerEvents:"none" }}/>

          <div style={{ position:"relative", zIndex:1 }}>
            <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".32em", textTransform:"uppercase", color:T.amber, margin:"0 0 24px" }}>[ 03 ] — Message Us</p>
            <h2 style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(2.2rem,4vw,3.8rem)", lineHeight:.92, letterSpacing:"-.04em", color:T.ink, textTransform:"uppercase", margin:"0 0 24px" }}>
              Send us<br/>a message<span style={{ color:T.amber }}>.</span>
            </h2>
            <div style={{ width:48, height:2, background:T.amber, marginBottom:24 }}/>
            <p style={{ fontFamily:T.body, fontSize:".95rem", color:"rgba(245,240,232,.5)", lineHeight:1.72, margin:"0 0 36px", fontWeight:300, maxWidth:320 }}>
              Fill in the form and we'll get back to you the same business day with an expert recommendation.
            </p>

            {/* Process steps */}
            {[["01","Fill the form","30 seconds"],["02","We review it","Same day"],["03","We call back","Expert advice"]].map(([n, title, sub]) => (
              <div key={n} style={{ display:"flex", alignItems:"center", gap:16, marginBottom:20 }}>
                <div style={{ width:32, height:32, borderRadius:"50%", background:`rgba(212,168,67,.12)`, border:`1px solid rgba(212,168,67,.3)`, display:"flex", alignItems:"center", justifyContent:"center", flexShrink:0 }}>
                  <span style={{ fontFamily:T.mono, fontSize:".58rem", color:T.amber, fontWeight:700 }}>{n}</span>
                </div>
                <div>
                  <p style={{ fontFamily:T.display, fontWeight:700, fontSize:".88rem", color:T.ink, margin:0 }}>{title}</p>
                  <p style={{ fontFamily:T.mono, fontSize:".58rem", color:"rgba(212,168,67,.55)", margin:0, letterSpacing:".1em" }}>{sub}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Bottom awards row */}
          <div style={{ position:"relative", zIndex:1, display:"flex", gap:20, flexWrap:"wrap", paddingTop:24, borderTop:`1px solid rgba(212,168,67,.12)` }}>
            {[["4.8★","Google Reviews"],["10K+","Happy Drivers"],["Same Day","Turnaround"]].map(([v, l]) => (
              <div key={l}>
                <p style={{ fontFamily:T.display, fontWeight:900, fontSize:"1rem", color:T.amber, margin:"0 0 2px" }}>{v}</p>
                <p style={{ fontFamily:T.mono, fontSize:".55rem", color:"rgba(245,240,232,.35)", letterSpacing:".12em", textTransform:"uppercase", margin:0 }}>{l}</p>
              </div>
            ))}
          </div>
        </div>

        {/* RIGHT — cream form panel */}
        <div style={{ background:T.paper, padding:"64px 52px", display:"flex", flexDirection:"column", justifyContent:"center", position:"relative", overflow:"hidden" }}>
          <div style={{ position:"absolute", top:"-10%", right:"-10%", width:300, height:300, borderRadius:"50%", background:`radial-gradient(circle,rgba(212,168,67,.08),transparent 65%)`, filter:"blur(40px)", pointerEvents:"none" }}/>

          <AnimatePresence mode="wait">
            {step === "sent" ? (
              <motion.div key="sent" initial={{opacity:0,scale:.9}} animate={{opacity:1,scale:1}} exit={{opacity:0}} transition={{duration:.4}} style={{ textAlign:"center", padding:"40px 20px", position:"relative", zIndex:1 }}>
                <div style={{ width:64, height:64, borderRadius:"50%", background:T.inkDark, display:"flex", alignItems:"center", justifyContent:"center", margin:"0 auto 20px", color:T.amber }}>
                  <ICheck/>
                </div>
                <h3 style={{ fontFamily:T.display, fontWeight:900, fontSize:"1.6rem", color:T.inkDark, margin:"0 0 10px", textTransform:"uppercase" }}>Message Received!</h3>
                <p style={{ fontFamily:T.body, fontSize:".95rem", color:"rgba(26,27,20,.55)", margin:"0 0 28px", lineHeight:1.6 }}>We'll call or email you back within the same business day.</p>
                <button className="cx-submit" onClick={() => setStep("form")} style={{ maxWidth:240, margin:"0 auto" }}>Send Another →</button>
              </motion.div>
            ) : (
              <motion.form key="form" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} transition={{duration:.3}} onSubmit={submit} style={{ position:"relative", zIndex:1 }}>
                <p style={{ fontFamily:T.mono, fontSize:".6rem", letterSpacing:".28em", textTransform:"uppercase", color:T.amber, fontWeight:700, margin:"0 0 28px" }}>Your Details</p>

                <div className="cx-form-cols" style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:"0 24px" }}>
                  <div className="cx-field-wrap">
                    <label className="cx-flabel">Full Name</label>
                    <input className="cx-field" type="text" placeholder="Your name" value={form.name} onChange={up("name")} required/>
                  </div>
                  <div className="cx-field-wrap">
                    <label className="cx-flabel">Phone</label>
                    <input className="cx-field" type="tel" placeholder="+91 xxxxx xxxxx" value={form.phone} onChange={up("phone")}/>
                  </div>
                  <div className="cx-field-wrap">
                    <label className="cx-flabel">Email</label>
                    <input className="cx-field" type="email" placeholder="your@email.com" value={form.email} onChange={up("email")} required/>
                  </div>
                  <div className="cx-field-wrap">
                    <label className="cx-flabel">Vehicle</label>
                    <input className="cx-field" type="text" placeholder="e.g. Honda City 2022" value={form.vehicle} onChange={up("vehicle")}/>
                  </div>
                </div>

                <div className="cx-field-wrap">
                  <label className="cx-flabel">Service Needed</label>
                  <select className="cx-field" value={form.service} onChange={up("service")}>
                    <option value="">Select a service…</option>
                    {["Tyre Replacement","Wheel Balancing","Wheel Alignment","Tyre Rotation","Puncture Repair","Nitrogen Inflation","Tyre Inspection","Performance Tyres","Commercial / Fleet","Not sure — need advice"].map(s => <option key={s}>{s}</option>)}
                  </select>
                </div>

                <div className="cx-field-wrap">
                  <label className="cx-flabel">Message</label>
                  <textarea className="cx-field" rows={3} placeholder="Tell us anything else — tyre size, budget, urgency…" value={form.message} onChange={up("message")} style={{ resize:"none" }}/>
                </div>

                <button type="submit" className="cx-submit" disabled={busy}>{busy ? "Sending…" : "Send Message →"}</button>
                <p style={{ fontFamily:T.mono, fontSize:".56rem", letterSpacing:".1em", color:"rgba(26,27,20,.35)", textAlign:"center", marginTop:12 }}>We respond within the same business day</p>
              </motion.form>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}

/* ============================================================================
   HOURS — horizontal strip (no grid, no split — just a clean timeline)
   ========================================================================== */
function HoursStrip() {
  const days = [
    { day:"Mon", full:"Monday",    h:"8:00 – 19:00" },
    { day:"Tue", full:"Tuesday",   h:"8:00 – 19:00" },
    { day:"Wed", full:"Wednesday", h:"8:00 – 19:00" },
    { day:"Thu", full:"Thursday",  h:"8:00 – 19:00" },
    { day:"Fri", full:"Friday",    h:"8:00 – 19:00" },
    { day:"Sat", full:"Saturday",  h:"8:00 – 18:00" },
    { day:"Sun", full:"Sunday",    h:"9:00 – 17:00" },
  ];
  const today = new Date().getDay(); // 0=Sun
  const todayIdx = today === 0 ? 6 : today - 1;

  return (
    <section style={{ background:T.bg, borderTop:`1px solid ${T.hairline}`, padding:"56px 56px 60px", position:"relative", overflow:"hidden" }}>
      <div style={{ position:"absolute", inset:0, backgroundImage:`radial-gradient(circle,rgba(212,168,67,.08) 1px,transparent 1px)`, backgroundSize:"40px 40px", pointerEvents:"none" }}/>
      <div style={{ maxWidth:1240, margin:"0 auto", position:"relative", zIndex:1 }}>
        <Rev style={{ marginBottom:36 }}>
          <div style={{ display:"flex", alignItems:"center", gap:16 }}>
            <p style={{ fontFamily:T.mono, fontSize:".6rem", letterSpacing:".32em", textTransform:"uppercase", color:T.amber, margin:0 }}>[ 04 ] — Opening Hours</p>
            <div style={{ flex:1, height:1, background:`linear-gradient(to right,${T.hairline},transparent)` }}/>
            <p style={{ fontFamily:T.mono, fontSize:".6rem", color:T.inkDim, margin:0 }}>Walk-ins welcome</p>
          </div>
        </Rev>

        {/* Horizontal day row */}
        <div className="cx-bar" style={{ display:"flex", gap:10, alignItems:"stretch" }}>
          {days.map((d, i) => (
            <Rev key={d.day} delay={i * 55} style={{ flex:1, minWidth:0 }}>
              <div style={{
                padding:"20px 14px 18px", borderRadius:4, textAlign:"center",
                background: i === todayIdx ? T.amber : "rgba(20,22,8,.85)",
                border:`1px solid ${i === todayIdx ? T.amber : T.hairline}`,
                transition:"all .25s",
              }}>
                <p style={{ fontFamily:T.mono, fontSize:".62rem", letterSpacing:".14em", textTransform:"uppercase", color: i === todayIdx ? T.inkDark : T.inkDim, margin:"0 0 6px", fontWeight:700 }}>{d.day}</p>
                <p style={{ fontFamily:T.display, fontWeight:800, fontSize:".85rem", color: i === todayIdx ? T.inkDark : T.ink, margin:"0 0 4px", lineHeight:1.1 }}>{d.h.split("–")[0]}</p>
                <p style={{ fontFamily:T.mono, fontSize:".58rem", color: i === todayIdx ? "rgba(26,27,20,.55)" : T.inkDim, margin:0 }}>→ {d.h.split("–")[1]}</p>
                {i === todayIdx && <div style={{ marginTop:8, fontFamily:T.mono, fontSize:".52rem", letterSpacing:".18em", color:T.inkDark, background:"rgba(26,27,20,.15)", padding:"3px 8px", borderRadius:999, display:"inline-block" }}>TODAY</div>}
              </div>
            </Rev>
          ))}
        </div>

        {/* Location row */}
        <Rev style={{ marginTop:28 }}>
          <div style={{ display:"flex", alignItems:"center", gap:20, padding:"18px 24px", background:"rgba(20,22,8,.8)", border:`1px solid ${T.hairline}`, borderRadius:6, flexWrap:"wrap", gap:16 }}>
            <div style={{ display:"flex", alignItems:"center", gap:10, color:T.amber }}>
              <IPin/><span style={{ fontFamily:T.display, fontWeight:700, fontSize:".9rem", color:T.ink }}>123 Tyre Lane, Industrial Area, Mumbai MH 400001</span>
            </div>
            <div style={{ flex:1 }}/>
            <a href="#" style={{ fontFamily:T.mono, fontSize:".6rem", letterSpacing:".14em", textTransform:"uppercase", color:T.amber, textDecoration:"none", display:"flex", alignItems:"center", gap:6 }}>
              Get Directions <IArrow/>
            </a>
          </div>
        </Rev>
      </div>
    </section>
  );
}

/* ============================================================================
   FOOTER CTA — minimal, different from About's full-panel CTA
   ========================================================================== */
function FooterCta() {
  return (
    <section style={{ background:T.paper, padding:"48px 56px", position:"relative", overflow:"hidden" }}>
      <div style={{ position:"absolute", inset:0, backgroundImage:`repeating-linear-gradient(60deg,rgba(26,27,20,.04) 0,rgba(26,27,20,.04) 1px,transparent 1px,transparent 32px)`, pointerEvents:"none" }}/>
      <div style={{ maxWidth:1240, margin:"0 auto", position:"relative", zIndex:1 }}>
        <div className="cx-footer-row" style={{ display:"flex", alignItems:"center", justifyContent:"space-between", gap:24, flexWrap:"wrap" }}>
          <div>
            <p style={{ fontFamily:T.mono, fontSize:".58rem", letterSpacing:".28em", textTransform:"uppercase", color:T.amber, margin:"0 0 6px" }}>[ 05 ] — Still have questions?</p>
            <h2 style={{ fontFamily:T.display, fontWeight:900, fontSize:"clamp(1.4rem,2.8vw,2.2rem)", color:T.inkDark, margin:0, letterSpacing:"-.02em", textTransform:"uppercase" }}>
              Our experts are ready.
            </h2>
          </div>
          <div style={{ display:"flex", gap:12, flexWrap:"wrap" }}>
            <a href={COMPANY.phoneHref??"tel:+91"} style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"13px 26px", background:T.inkDark, color:T.amber, fontFamily:T.display, fontWeight:800, fontSize:".88rem", letterSpacing:".03em", textDecoration:"none", borderRadius:2, transition:"background .2s, box-shadow .2s" }}
              onMouseEnter={e=>{ (e.currentTarget as HTMLAnchorElement).style.background=T.amber; (e.currentTarget as HTMLAnchorElement).style.color=T.inkDark; }}
              onMouseLeave={e=>{ (e.currentTarget as HTMLAnchorElement).style.background=T.inkDark; (e.currentTarget as HTMLAnchorElement).style.color=T.amber; }}>
              <IPhone/> Call Now
            </a>
            <Link to={ROUTES.tyres} style={{ display:"inline-flex", alignItems:"center", gap:8, padding:"13px 26px", background:"transparent", color:T.inkDark, fontFamily:T.display, fontWeight:700, fontSize:".88rem", letterSpacing:".03em", textDecoration:"none", borderRadius:2, border:`1px solid rgba(26,27,20,.25)`, transition:"border-color .2s" }}
              onMouseEnter={e=>((e.currentTarget as HTMLAnchorElement).style.borderColor=T.amber)}
              onMouseLeave={e=>((e.currentTarget as HTMLAnchorElement).style.borderColor="rgba(26,27,20,.25)")}>
              Browse Tyres →
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ============================================================================
   EXPORT
   ========================================================================== */
export default function ContactUs() {
  return (
    <div className="cx-root" style={{ fontFamily:T.body, background:T.bg, color:T.ink, minHeight:"100vh", overflowX:"hidden", WebkitFontSmoothing:"antialiased" }}>
      <style>{CSS}</style>
      <VerticalRail/>
      <Hero/>
      <BentoSection/>
      <FormSection/>
      <HoursStrip/>
      <FooterCta/>
    </div>
  );
}
